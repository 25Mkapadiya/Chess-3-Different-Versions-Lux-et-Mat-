@echo off
cd /d "%~dp0"
java -jar Lux-et-Mat.jar
if errorlevel 1 (
  echo.
  echo Lux et Mat could not start.
  echo Make sure Java 8 or newer is installed, then try again.
  echo.
  pause
)
